<!DOCTYPE html>
	<!--[if IE 8]>
		<html xmlns="http://www.w3.org/1999/xhtml" class="ie8" lang="en-GB"
	prefix="og: https://ogp.me/ns#" >
	<![endif]-->
	<!--[if !(IE 8) ]><!-->
		<html xmlns="http://www.w3.org/1999/xhtml" lang="en-GB"
	prefix="og: https://ogp.me/ns#" >
	<!--<![endif]-->
	<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title>Log In &lsaquo; Canonn Research Group &#8212; WordPress</title>
	<link rel='dns-prefetch' href='//s.w.org' />
<link rel='stylesheet' id='dashicons-css'  href='//cdn-5f3c0a05c1ac180394b62f3c.closte.com/wp-includes/css/dashicons.min.css?ver=5.4.16' type='text/css' media='all' />
<link rel='stylesheet' id='buttons-css'  href='//cdn-5f3c0a05c1ac180394b62f3c.closte.com/wp-includes/css/buttons.min.css?ver=5.4.16' type='text/css' media='all' />
<link rel='stylesheet' id='forms-css'  href='//cdn-5f3c0a05c1ac180394b62f3c.closte.com/wp-admin/css/forms.min.css?ver=5.4.16' type='text/css' media='all' />
<link rel='stylesheet' id='l10n-css'  href='//cdn-5f3c0a05c1ac180394b62f3c.closte.com/wp-admin/css/l10n.min.css?ver=5.4.16' type='text/css' media='all' />
<link rel='stylesheet' id='login-css'  href='//cdn-5f3c0a05c1ac180394b62f3c.closte.com/wp-admin/css/login.min.css?ver=5.4.16' type='text/css' media='all' />
<style>
	.login h1 a {
		background-image: url(//cdn-5f3c0a05c1ac180394b62f3c.closte.com/wp-content/uploads/2017/04/cropped-biscuit-150x150.png) !important;
		background-size: contain;
		width: auto;
		}
	</style>	<meta name='robots' content='noindex,noarchive' />
	<meta name='referrer' content='strict-origin-when-cross-origin' />
		<meta name="viewport" content="width=device-width" />
	<link rel="icon" href="//cdn-5f3c0a05c1ac180394b62f3c.closte.com/wp-content/uploads/2017/04/cropped-biscuit-32x32.png" sizes="32x32" />
<link rel="icon" href="//cdn-5f3c0a05c1ac180394b62f3c.closte.com/wp-content/uploads/2017/04/cropped-biscuit-192x192.png" sizes="192x192" />
<link rel="apple-touch-icon" href="//cdn-5f3c0a05c1ac180394b62f3c.closte.com/wp-content/uploads/2017/04/cropped-biscuit-180x180.png" />
<meta name="msapplication-TileImage" content="https://canonn.science/wp-content/uploads/2017/04/cropped-biscuit-270x270.png" />
	</head>
	<body class="login no-js login-action-login wp-core-ui  locale-en-gb">
	<script type="text/javascript">
		document.body.className = document.body.className.replace('no-js','js');
	</script>
		<div id="login">
		<h1><a href="https://en-gb.wordpress.org/">Powered by WordPress</a></h1>
	
		<form name="loginform" id="loginform" action="https://canonn.science/wp-login.php" method="post">
			<p>
				<label for="user_login">Username or Email Address</label>
				<input type="text" name="log" id="user_login" class="input" value="" size="20" autocapitalize="off" />
			</p>

			<div class="user-pass-wrap">
				<label for="user_pass">Password</label>
				<div class="wp-pwd">
					<input type="password" name="pwd" id="user_pass" class="input password-input" value="" size="20" />
					<button type="button" class="button button-secondary wp-hide-pw hide-if-no-js" data-toggle="0" aria-label="Show password">
						<span class="dashicons dashicons-visibility" aria-hidden="true"></span>
					</button>
				</div>
			</div>
						<p class="forgetmenot"><input name="rememberme" type="checkbox" id="rememberme" value="forever"  /> <label for="rememberme">Remember Me</label></p>
			<p class="submit">
				<input type="submit" name="wp-submit" id="wp-submit" class="button button-primary button-large" value="Log In" />
									<input type="hidden" name="redirect_to" value="https://canonn.science/wp-admin/" />
									<input type="hidden" name="testcookie" value="1" />
			</p>
		</form>

					<p id="nav">
				<a href="https://canonn.science/wp-login.php?action=register">Register</a> | 					<a href="https://canonn.science/wp-login.php?action=lostpassword">Lost your password?</a>
								</p>
					<script type="text/javascript">
			function wp_attempt_focus() {setTimeout( function() {try {d = document.getElementById( "user_login" );d.focus(); d.select();} catch( er ) {}}, 200);}
wp_attempt_focus();
if ( typeof wpOnload === 'function' ) { wpOnload() }		</script>
				<p id="backtoblog"><a href="https://canonn.science/">
		&larr; Back to Canonn Research Group		</a></p>
			</div>
	<script type='text/javascript' src='//cdn-5f3c0a05c1ac180394b62f3c.closte.com/wp-includes/js/jquery/jquery.js?ver=1.12.4-wp'></script>
<script type='text/javascript' src='//cdn-5f3c0a05c1ac180394b62f3c.closte.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var _zxcvbnSettings = {"src":"\/\/cdn-5f3c0a05c1ac180394b62f3c.closte.com\/wp-includes\/js\/zxcvbn.min.js"};
/* ]]> */
</script>
<script type='text/javascript' src='//cdn-5f3c0a05c1ac180394b62f3c.closte.com/wp-includes/js/zxcvbn-async.min.js?ver=1.0'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var pwsL10n = {"unknown":"Password strength unknown","short":"Very weak","bad":"Weak","good":"Medium","strong":"Strong","mismatch":"Mismatch"};
/* ]]> */
</script>
<script type='text/javascript' src='//cdn-5f3c0a05c1ac180394b62f3c.closte.com/wp-admin/js/password-strength-meter.min.js?ver=5.4.16'></script>
<script type='text/javascript' src='//cdn-5f3c0a05c1ac180394b62f3c.closte.com/wp-includes/js/underscore.min.js?ver=1.8.3'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var _wpUtilSettings = {"ajax":{"url":"\/wp-admin\/admin-ajax.php"}};
/* ]]> */
</script>
<script type='text/javascript' src='//cdn-5f3c0a05c1ac180394b62f3c.closte.com/wp-includes/js/wp-util.min.js?ver=5.4.16'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var userProfileL10n = {"warn":"Your new password has not been saved.","warnWeak":"Confirm use of weak password","show":"Show","hide":"Hide","cancel":"Cancel","ariaShow":"Show password","ariaHide":"Hide password"};
/* ]]> */
</script>
<script type='text/javascript' src='//cdn-5f3c0a05c1ac180394b62f3c.closte.com/wp-admin/js/user-profile.min.js?ver=5.4.16'></script>
	<div class="clear"></div>
	</body>
	</html>
	